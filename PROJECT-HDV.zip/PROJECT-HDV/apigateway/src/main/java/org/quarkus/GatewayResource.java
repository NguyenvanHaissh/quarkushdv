package org.quarkus;

import io.smallrye.mutiny.Uni;
// import io.vertx.core.MultiMap;
import io.vertx.mutiny.core.MultiMap;
import io.vertx.mutiny.core.buffer.Buffer;
import io.vertx.mutiny.ext.web.client.HttpResponse;
import io.vertx.mutiny.ext.web.client.WebClient;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@Path("/{service}")
@Consumes(MediaType.WILDCARD)
@Produces(MediaType.WILDCARD)
public class GatewayResource {

    @Inject
    WebClient webClient;

    @ConfigProperty(name = "gateway.user.url")
    String userUrl;

    @ConfigProperty(name = "gateway.product.url")
    String productUrl;

    @ConfigProperty(name = "gateway.payment.url")
    String paymentUrl;

    // ========= GET =========
    @GET
    @Path("{path:.*}")
    public Uni<Response> proxyGet(
            @PathParam("service") String service,
            @PathParam("path") String path,
            @Context UriInfo uriInfo,
            @Context HttpHeaders headers) {

        return webClient
                .getAbs(buildUrl(service, path, uriInfo))
                .putHeaders(copyHeaders(headers))
                .send()
                .onItem().transform(this::toResponse);
    }

    // ========= POST =========
    @POST
    @Path("{path:.*}")
    public Uni<Response> proxyPost(
            @PathParam("service") String service,
            @PathParam("path") String path,
            Buffer body,
            @Context UriInfo uriInfo,
            @Context HttpHeaders headers) {

        return webClient
                .postAbs(buildUrl(service, path, uriInfo))
                .putHeaders(copyHeaders(headers))
                .sendBuffer(body)
                .onItem().transform(this::toResponse);
    }

    // ========= PUT =========
    @PUT
    @Path("{path:.*}")
    public Uni<Response> proxyPut(
            @PathParam("service") String service,
            @PathParam("path") String path,
            Buffer body,
            @Context UriInfo uriInfo,
            @Context HttpHeaders headers) {

        return webClient
                .putAbs(buildUrl(service, path, uriInfo))
                .putHeaders(copyHeaders(headers))
                .sendBuffer(body)
                .onItem().transform(this::toResponse);
    }

    // ========= DELETE =========
    @DELETE
    @Path("{path:.*}")
    public Uni<Response> proxyDelete(
            @PathParam("service") String service,
            @PathParam("path") String path,
            @Context UriInfo uriInfo,
            @Context HttpHeaders headers) {

        return webClient
                .deleteAbs(buildUrl(service, path, uriInfo))
                .putHeaders(copyHeaders(headers))
                .send()
                .onItem().transform(this::toResponse);
    }

    // ========= HELPERS =========

    private String buildUrl(String service, String path, UriInfo uriInfo) {
        String baseUrl = switch (service.toLowerCase()) {
            case "users" -> userUrl;
            case "products" -> productUrl;
            case "payments" -> paymentUrl;
            default -> throw new NotFoundException("Service not found: " + service);
        };

        String url = baseUrl + "/" + service;
        if (!path.isEmpty()) url += "/" + path;

        if (uriInfo.getRequestUri().getQuery() != null) {
            url += "?" + uriInfo.getRequestUri().getQuery();
        }
        return url;
    }

    private MultiMap copyHeaders(HttpHeaders headers) {
        MultiMap map = MultiMap.caseInsensitiveMultiMap();
        headers.getRequestHeaders().forEach((k, v) -> {
            if (!k.equalsIgnoreCase("host")
             && !k.equalsIgnoreCase("content-length")
             && !k.equalsIgnoreCase("connection")) {
                v.forEach(value -> map.add(k, value));
            }
        });
        return map;
    }

    private Response toResponse(HttpResponse<Buffer> res) {
        Response.ResponseBuilder builder = Response
                .status(res.statusCode())
                .entity(res.body());

        res.headers().forEach(h -> {
            if (!h.getKey().equalsIgnoreCase("Transfer-Encoding")) {
                builder.header(h.getKey(), h.getValue());
            }
        });
        return builder.build();
    }
}
