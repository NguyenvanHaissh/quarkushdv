package org.project;

import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/users")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UserResource {

    @GET
    public List<User> list() {
        return User.listAll();
    }

    @GET
    @Path("/{id}")
    public User get(@PathParam("id") Long id) {
        User user = User.findById(id);
        if (user == null) throw new NotFoundException();
        return user;
    }

    @POST
    @Transactional
    public Response create(User user) {
        user.persist();
        return Response.status(201).entity(user).build();
    }

    // Endpoint để lấy danh sách sản phẩm đã mua (dành cho payment-service gọi)
    @GET
    @Path("/{id}/purchased-products")
    public List<Long> getPurchasedProducts(@PathParam("id") Long id) {
        User user = User.findById(id);
        if (user == null) throw new NotFoundException();
        return user.purchasedProductIds;
    }

    // Endpoint để thêm sản phẩm vào lịch sử mua (demo mua hàng)
    @POST
    @Path("/{id}/purchase")
    @Transactional
    public Response purchase(@PathParam("id") Long id, List<Long> productIds) {
        User user = User.findById(id);
        if (user == null) throw new NotFoundException();
        user.purchasedProductIds.addAll(productIds);
        return Response.ok().build();
    }
    
}
