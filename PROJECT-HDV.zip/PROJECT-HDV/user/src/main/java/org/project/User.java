package org.project;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "app_user")
public class User extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;


    public String username;
    public String email;

    // Danh sách ID sản phẩm người dùng đã mua
    @ElementCollection
    public List<Long> purchasedProductIds = new ArrayList<>();
}