package org.project;

import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/products")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ProductResource {

    @GET
    public List<Product> list() {
        return Product.listAll();
    }

    // @GET
    // @Path("/{id}")
    // public Product get(Long id) {
    //     return Product.findById(id);
    // }
    @GET
@Path("/{id}")
public Product get(@PathParam("id") Long id) {
    Product product = Product.findById(id);
    if (product == null) {
        throw new NotFoundException("Product not found with id: " + id);
    }
    return product;
}

    @POST
    @Transactional
    public Response create(Product product) {
        product.persist();
        return Response.status(201).entity(product).build();
    }

    @PUT
    @Path("/{id}")
    @Transactional
    public Product update(Long id, Product updated) {
        Product entity = Product.findById(id);
        if (entity == null) {
            throw new NotFoundException();
        }
        entity.name = updated.name;
        entity.description = updated.description;
        entity.price = updated.price;
        return entity;
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public Response delete(Long id) {
        boolean deleted = Product.deleteById(id);
        return deleted ? Response.noContent().build() : Response.status(404).build();
    }
}