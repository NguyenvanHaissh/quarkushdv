package org.project;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.List;
import java.util.Optional;

@Path("/payments")
@Produces(MediaType.APPLICATION_JSON)
public class PaymentResource {

    @Inject @RestClient UserClient userClient;
    @Inject @RestClient ProductClient productClient;

@GET
@Path("/invoice/{userId}")
public Invoice generateInvoice(@PathParam("userId") Long userId) {
    // Lấy thông tin user
    UserDto user = userClient.getUser(userId);

    // Lấy danh sách product đã mua
    List<Long> productIds = userClient.getPurchasedProducts(userId);
    if (productIds.isEmpty()) {
        throw new BadRequestException("Người dùng chưa mua sản phẩm nào");
    }

    // Lấy thông tin sản phẩm, lọc bỏ những cái không tồn tại
var items = productIds.stream()
    .distinct()
    
    .map(id -> productClient.getProduct(id)) 
    
    .filter(opt -> opt != null) 
    
    // Bước 2: flatMap loại bỏ Optional rỗng (empty)
    .flatMap(Optional::stream) 

    // Bước 3: Ánh xạ ProductDto an toàn sang Invoice.Item
    .map(p -> new Invoice.Item(p.id(), p.name(), p.price()))
    .toList();

    if (items.isEmpty()) {
        throw new BadRequestException("Không tìm thấy thông tin sản phẩm nào đã mua");
    }

    double total = items.stream().mapToDouble(Invoice.Item::price).sum();

    return new Invoice(user.username(), total, items);
}
}
