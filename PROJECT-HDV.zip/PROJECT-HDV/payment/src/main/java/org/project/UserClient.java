package org.project;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import java.util.List;

@RegisterRestClient(configKey = "user-api")
public interface UserClient {

    @GET
    @Path("/users/{id}")
    UserDto getUser(@PathParam("id") Long id);

    @GET
    @Path("/users/{id}/purchased-products")
    List<Long> getPurchasedProducts(@PathParam("id") Long id);
}
