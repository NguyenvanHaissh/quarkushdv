package org.project;

public record ProductDto(Long id, String name, double price) {}