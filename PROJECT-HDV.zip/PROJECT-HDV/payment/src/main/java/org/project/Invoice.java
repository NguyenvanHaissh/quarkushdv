package org.project;


import java.util.List;

public record Invoice(String username, double totalAmount, List<Item> items) {
    public record Item(Long productId, String productName, double price) {}
}