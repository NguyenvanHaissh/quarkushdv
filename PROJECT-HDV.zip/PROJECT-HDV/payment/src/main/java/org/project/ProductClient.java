package org.project;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
// File: ProductClient.java

import java.util.Optional; // Bắt buộc

@RegisterRestClient(configKey = "product-api")
public interface ProductClient {
    @GET
    @Path("/products/{id}")
    // PHẢI trả về Optional để xử lý 404/204 an toàn
    Optional<ProductDto> getProduct(@PathParam("id") Long id); 
}
