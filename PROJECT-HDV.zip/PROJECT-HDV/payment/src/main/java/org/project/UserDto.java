package org.project;

public record UserDto(Long id, String username) {}
